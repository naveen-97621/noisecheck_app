// NoiseCheck — Tamil Nadu Noise Intelligence Platform Logic

const API_BASE = "http://127.0.0.1:8000";

// Mapbox Token
const MAPBOX_TOKEN = "pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4M29iazA2Z2gycXA4N2pmbDZmangifQ.-g_vE53SD2WrJ6tFX7QHmA";

// Default Center: Tamil Nadu State Center (Latitude: 11.1271, Longitude: 78.6569, Zoom: 6.5)
const TN_CENTER_LAT = 11.1271;
const TN_CENTER_LNG = 78.6569;
const TN_DEFAULT_ZOOM = 6.5;

let currentLat = TN_CENTER_LAT;
let currentLng = TN_CENTER_LNG;
let map = null;
let activeMarker = null;
let noiseChart = null;
let activeScoreData = null;
let selectedDayType = "all"; // "weekday" | "weekend" | "all"
let selectedTimeOfDay = "all"; // "morning" | "afternoon" | "evening" | "night" | "all"
let dotLayerVisible = false; // DOT federal transportation noise overlay

// Debounce Timer
let mapMoveTimeout = null;

// Hover Tooltip Popup
let hoverPopup = null;

// Web Audio API State
let audioContext = null;
let mediaStream = null;
let analyserNode = null;
let isMetering = false;
let recordedDb = 0;

// Initialize App
document.addEventListener("DOMContentLoaded", () => {
  initAuth();
  initTNMap();
  setupEventListeners();
  // Fetch initial score for Chennai Central as default starting point
  fetchLocationScore(13.0827, 80.2707, "Chennai Central (Default Hub)");
});

// Initialize Maplibre GL Map centered on Tamil Nadu
function initTNMap() {
  map = new maplibregl.Map({
    container: 'map',
    style: 'https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json',
    center: [TN_CENTER_LNG, TN_CENTER_LAT],
    zoom: TN_DEFAULT_ZOOM,
  });

  // Native Controls
  map.addControl(new maplibregl.NavigationControl(), 'top-right');
  map.addControl(new maplibregl.FullscreenControl(), 'top-right');
  map.addControl(new maplibregl.ScaleControl({ unit: 'metric' }), 'bottom-right');

  hoverPopup = new maplibregl.Popup({ closeButton: false, closeOnClick: false });

  map.on('load', () => {
    loadTNDistrictBoundaries();
    setupMapLayers();
    setupDotNoiseLayer();
    addCityLabels();
    fetchHeatmapPoints();

    // Debounced bounds refetch on map move / zoom
    map.on('moveend', () => {
      clearTimeout(mapMoveTimeout);
      mapMoveTimeout = setTimeout(() => {
        fetchHeatmapPoints();
      }, 300);
    });

    // Map click handler (updates location & right side panel)
    map.on('click', (e) => {
      const lat = e.lngLat.lat;
      const lng = e.lngLat.lng;
      setMapMarker(lat, lng);
      fetchLocationScore(lat, lng, `Selected Point (${lat.toFixed(4)}, ${lng.toFixed(4)})`);
    });

    // Hover tooltip on noise points
    map.on('mouseenter', 'noise-points', (e) => {
      map.getCanvas().style.cursor = 'pointer';
      if (e.features && e.features.length > 0) {
        const feat = e.features[0];
        const coords = feat.geometry.coordinates.slice();
        const db = feat.properties.db;
        const tag = feat.properties.tag;

        hoverPopup
          .setLngLat(coords)
          .setHTML(`<div style="color:#0f172a; font-weight:700; padding:2px 4px; font-size:12px;"><strong>${db} dB</strong> (${tag})</div>`)
          .addTo(map);
      }
    });

    map.on('mouseleave', 'noise-points', () => {
      map.getCanvas().style.cursor = '';
      hoverPopup.remove();
    });
  });
}

// Load Tamil Nadu District & State Boundary Overlay
async function loadTNDistrictBoundaries() {
  try {
    const res = await fetch('/tn_districts.json');
    const data = await res.json();

    map.addSource('tn-boundaries-src', {
      type: 'geojson',
      data: data
    });

    // State Fill Layer (Subtle 4% opacity)
    map.addLayer({
      id: 'tn-state-fill',
      type: 'fill',
      source: 'tn-boundaries-src',
      paint: {
        'fill-color': '#8b5cf6',
        'fill-opacity': 0.04
      }
    });

    // District & State Boundary Lines (Thin 1.2px purple accent)
    map.addLayer({
      id: 'tn-district-lines',
      type: 'line',
      source: 'tn-boundaries-src',
      paint: {
        'line-color': '#a855f7',
        'line-width': 1.2,
        'line-opacity': 0.35
      }
    });
  } catch (err) {
    console.error("Error loading TN district boundary GeoJSON:", err);
  }
}

// Setup Noise Heatmap & Circle Layers
function setupMapLayers() {
  map.addSource('noise-reports-src', {
    type: 'geojson',
    data: { type: 'FeatureCollection', features: [] }
  });

  // Mapbox GL built-in Heatmap Layer
  map.addLayer({
    id: 'noise-heatmap',
    type: 'heatmap',
    source: 'noise-reports-src',
    paint: {
      'heatmap-weight': [
        'interpolate', ['linear'], ['get', 'db'],
        30, 0.1,
        50, 0.4,
        65, 0.75,
        85, 1.0
      ],
      'heatmap-intensity': [
        'interpolate', ['linear'], ['zoom'],
        6, 0.7,
        10, 1.2,
        15, 2.0
      ],
      // Color ramp matching legend exactly:
      // Green (#22C55E) -> Yellow (#FACC15) -> Orange (#F97316) -> Red (#EF4444)
      'heatmap-color': [
        'interpolate', ['linear'], ['heatmap-density'],
        0, 'rgba(0,0,0,0)',
        0.2, '#22c55e',
        0.5, '#facc15',
        0.8, '#f97316',
        1.0, '#ef4444'
      ],
      'heatmap-radius': [
        'interpolate', ['linear'], ['zoom'],
        6, 14,
        10, 26,
        15, 45
      ],
      'heatmap-opacity': 0.85
    }
  });

  // Circle point layer overlay
  map.addLayer({
    id: 'noise-points',
    type: 'circle',
    source: 'noise-reports-src',
    paint: {
      'circle-radius': 4.5,
      'circle-color': [
        'interpolate', ['linear'], ['get', 'db'],
        45, '#22c55e',
        55, '#facc15',
        65, '#f97316',
        75, '#ef4444'
      ],
      'circle-stroke-color': '#ffffff',
      'circle-stroke-width': 0.8,
      'circle-opacity': 0.8
    }
  });
}

// Setup DOT Federal Transportation Noise Raster Tile Overlay Layer
function setupDotNoiseLayer() {
  const DOT_TILE_URL = "https://geo.dot.gov/server/rest/services/Hosted/NTAD_Noise_2020_CONUS_Aviation_Road_Rail/MapServer/tile/{z}/{y}/{x}";

  map.addSource('dot-noise-src', {
    type: 'raster',
    tiles: [DOT_TILE_URL],
    tileSize: 256,
    minzoom: 1,
    maxzoom: 12,
    attribution: '© US DOT BTS NTAD 2020 Transportation Noise Map'
  });

  map.addLayer({
    id: 'dot-noise-layer',
    type: 'raster',
    source: 'dot-noise-src',
    paint: {
      'raster-opacity': 0,       // Hidden by default — toggle via button
      'raster-opacity-transition': { duration: 400 }
    }
  }, 'noise-heatmap'); // Insert BELOW heatmap so crowdsourced data stays on top
}

// Toggle DOT Federal Transportation Noise Overlay
function toggleDotLayer() {
  dotLayerVisible = !dotLayerVisible;
  const opacity = dotLayerVisible ? 0.55 : 0;
  map.setPaintProperty('dot-noise-layer', 'raster-opacity', opacity);

  const btn = document.getElementById("dot-layer-toggle");
  if (btn) {
    btn.classList.toggle("active", dotLayerVisible);
    btn.title = dotLayerVisible
      ? "Hide DOT Federal Transportation Noise Overlay"
      : "Show DOT Federal Transportation Noise Overlay (US only)";
  }
}

// Add City Labels for major Tamil Nadu cities
function addCityLabels() {
  const citiesGeojson = {
    type: 'FeatureCollection',
    features: [
      { type: 'Feature', geometry: { type: 'Point', coordinates: [80.2707, 13.0827] }, properties: { title: 'Chennai' } },
      { type: 'Feature', geometry: { type: 'Point', coordinates: [76.9558, 11.0168] }, properties: { title: 'Coimbatore' } },
      { type: 'Feature', geometry: { type: 'Point', coordinates: [78.1193, 9.9195] }, properties: { title: 'Madurai' } },
      { type: 'Feature', geometry: { type: 'Point', coordinates: [78.1460, 11.6643] }, properties: { title: 'Salem' } },
      { type: 'Feature', geometry: { type: 'Point', coordinates: [78.6946, 10.7905] }, properties: { title: 'Trichy' } },
      { type: 'Feature', geometry: { type: 'Point', coordinates: [77.3411, 11.1085] }, properties: { title: 'Tiruppur' } },
      { type: 'Feature', geometry: { type: 'Point', coordinates: [79.1325, 12.9165] }, properties: { title: 'Vellore' } },
      { type: 'Feature', geometry: { type: 'Point', coordinates: [77.7567, 8.7139] }, properties: { title: 'Tirunelveli' } },
      { type: 'Feature', geometry: { type: 'Point', coordinates: [76.6950, 11.4102] }, properties: { title: 'Ooty' } },
      { type: 'Feature', geometry: { type: 'Point', coordinates: [77.7172, 11.3410] }, properties: { title: 'Erode' } },
    ]
  };

  map.addSource('tn-city-labels-src', {
    type: 'geojson',
    data: citiesGeojson
  });

  map.addLayer({
    id: 'tn-city-labels',
    type: 'symbol',
    source: 'tn-city-labels-src',
    layout: {
      'text-field': ['get', 'title'],
      'text-font': ['Open Sans Bold', 'Arial Unicode MS Bold'],
      'text-size': 12,
      'text-anchor': 'top',
      'text-offset': [0, 0.5]
    },
    paint: {
      'text-color': '#f8fafc',
      'text-halo-color': '#0f172a',
      'text-halo-width': 2
    }
  });
}

function setMapMarker(lat, lng) {
  if (activeMarker) {
    activeMarker.setLngLat([lng, lat]);
  } else {
    const el = document.createElement('div');
    el.className = 'custom-marker';
    el.innerHTML = '<i class="fa-solid fa-location-dot" style="color:#ec4899; font-size:30px; filter:drop-shadow(0 4px 8px rgba(0,0,0,0.7));"></i>';
    activeMarker = new maplibregl.Marker(el)
      .setLngLat([lng, lat])
      .addTo(map);
  }
}

// Fetch Heatmap Points based on visible map bounds & active filters
async function fetchHeatmapPoints() {
  if (!map) return;

  try {
    const bounds = map.getBounds();
    const minLat = bounds.getSouth();
    const maxLat = bounds.getNorth();
    const minLng = bounds.getWest();
    const maxLng = bounds.getEast();

    const queryParams = new URLSearchParams({
      min_lat: minLat,
      max_lat: maxLat,
      min_lng: minLng,
      max_lng: maxLng,
      day_type: selectedDayType,
      time_of_day: selectedTimeOfDay,
      limit: 3500
    });

    const res = await fetch(`${API_BASE}/reports?${queryParams.toString()}`);
    const reports = await res.json();

    const geojson = {
      type: 'FeatureCollection',
      features: reports.map(r => ({
        type: 'Feature',
        geometry: {
          type: 'Point',
          coordinates: [r.lng, r.lat]
        },
        properties: {
          id: r.id,
          db: r.decibel_estimate,
          tag: r.tag,
          source: r.source,
          timestamp: r.timestamp
        }
      }))
    };

    if (map.getSource('noise-reports-src')) {
      map.getSource('noise-reports-src').setData(geojson);
    }
  } catch (err) {
    console.error("Error fetching TN heatmap bounds data:", err);
  }
}

// Fetch Aggregated Score for Selected Location
async function fetchLocationScore(lat, lng, locationTitle) {
  currentLat = lat;
  currentLng = lng;

  try {
    const res = await fetch(`${API_BASE}/score?lat=${lat}&lng=${lng}&radius=500`);
    const data = await res.json();
    activeScoreData = data;

    renderScorePanel(data, locationTitle);
  } catch (err) {
    console.error("Error fetching score:", err);
  }
}

// Render Side Panel Content
function renderScorePanel(data, locationTitle) {
  document.getElementById("empty-state").classList.add("hidden");
  document.getElementById("location-stats").classList.remove("hidden");

  document.getElementById("selected-address-title").textContent = locationTitle || "Location Analysis";
  document.getElementById("selected-coords").textContent = `Lat: ${data.lat.toFixed(4)}, Lng: ${data.lng.toFixed(4)}`;

  const scoreNum = data.overall_score_1_to_5;
  const dbValue = data.overall_db.toFixed(1);
  const badgeEl = document.getElementById("score-badge");

  badgeEl.className = `score-badge score-${scoreNum}`;
  document.getElementById("score-num").textContent = scoreNum;
  document.getElementById("db-value").textContent = dbValue;

  const scoreLabels = {
    1: "Quiet Residential Area",
    2: "Moderate Urban Environment",
    3: "Active Commercial Zone",
    4: "High Noise Traffic Corridor",
    5: "Extreme Industrial / Hub Noise"
  };
  document.getElementById("score-label").textContent = scoreLabels[scoreNum] || "Moderate Noise Level";

  document.getElementById("report-count-tag").innerHTML = `<i class="fa-solid fa-database"></i> ${data.report_count} reports`;

  // --- DOT Federal Baseline ---
  const dotCard = document.getElementById("dot-baseline-card");
  const dotNoDataCard = document.getElementById("dot-nodata-card");
  const dotDbSpan = document.getElementById("dot-db-value");
  const dotIndicator = document.getElementById("dot-db-indicator");

  const dotDb = data.dot_baseline_db;

  if (dotDb !== null && dotDb !== undefined) {
    dotCard.classList.remove("hidden");
    dotNoDataCard.classList.add("hidden");
    dotDbSpan.textContent = dotDb.toFixed(0);

    // Color indicator based on dB value
    let indicatorColor, indicatorLabel;
    if (dotDb < 50) {
      indicatorColor = "#22c55e"; indicatorLabel = "Low";
    } else if (dotDb < 60) {
      indicatorColor = "#facc15"; indicatorLabel = "Moderate";
    } else if (dotDb < 70) {
      indicatorColor = "#f97316"; indicatorLabel = "High";
    } else {
      indicatorColor = "#ef4444"; indicatorLabel = "Very High";
    }
    dotIndicator.textContent = indicatorLabel;
    dotIndicator.style.background = indicatorColor + "22";
    dotIndicator.style.color = indicatorColor;
    dotIndicator.style.borderColor = indicatorColor + "55";
  } else {
    // No DOT data (non-US location or no road/rail/aviation nearby)
    dotCard.classList.add("hidden");
    dotNoDataCard.classList.remove("hidden");
  }

  // Render Tags
  const tagsContainer = document.getElementById("tags-container");
  tagsContainer.innerHTML = "";
  const tagIcons = {
    nightlife: "fa-martini-glass-citrus",
    trains: "fa-train",
    traffic: "fa-car",
    construction: "fa-helmet-safety",
    other: "fa-volume-high",
    seed: "fa-seedling"
  };

  if (data.top_tags && data.top_tags.length > 0) {
    data.top_tags.forEach(tag => {
      const icon = tagIcons[tag] || "fa-volume-high";
      const tagEl = document.createElement("span");
      tagEl.className = "tag-badge";
      tagEl.innerHTML = `<i class="fa-solid ${icon}"></i> ${tag}`;
      tagsContainer.appendChild(tagEl);
    });
  } else {
    tagsContainer.innerHTML = '<span class="subtext">No distinct noise drivers recorded</span>';
  }

  // Render Chart
  renderChart(data);
}

// Render Decibel Profile Chart
function renderChart(data) {
  const ctx = document.getElementById('noise-chart').getContext('2d');

  const tod = data.time_of_day;
  const chartData = [tod.morning, tod.afternoon, tod.evening, tod.night];

  if (noiseChart) {
    noiseChart.destroy();
  }

  noiseChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Morning (6-12)', 'Afternoon (12-18)', 'Evening (18-22)', 'Night (22-6)'],
      datasets: [{
        label: 'Est. Decibels (dB)',
        data: chartData,
        backgroundColor: [
          'rgba(139, 92, 246, 0.75)',
          'rgba(59, 130, 246, 0.75)',
          'rgba(249, 115, 22, 0.75)',
          'rgba(236, 72, 153, 0.85)'
        ],
        borderColor: [
          '#8b5cf6',
          '#3b82f6',
          '#f97316',
          '#ec4899'
        ],
        borderWidth: 1.5,
        borderRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: false,
          min: 30,
          max: 105,
          grid: { color: 'rgba(255, 255, 255, 0.08)' },
          ticks: { color: '#94a3b8', font: { size: 10 } }
        },
        x: {
          grid: { display: false },
          ticks: { color: '#94a3b8', font: { size: 10 } }
        }
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (context) => `${context.raw} dB`
          }
        }
      }
    }
  });
}

// Setup Event Listeners
function setupEventListeners() {
  // Address Search
  const searchInput = document.getElementById("address-search");
  const searchBtn = document.getElementById("search-btn");

  searchBtn.addEventListener("click", () => handleAddressSearch(searchInput.value));
  searchInput.addEventListener("keypress", (e) => {
    if (e.key === 'Enter') handleAddressSearch(searchInput.value);
  });

  // Reset TN View Button
  document.getElementById("reset-tn-btn").addEventListener("click", () => {
    map.flyTo({ center: [TN_CENTER_LNG, TN_CENTER_LAT], zoom: TN_DEFAULT_ZOOM });
  });

  // Hotspot Chips
  document.querySelectorAll(".chip-btn").forEach(chip => {
    chip.addEventListener("click", () => {
      const lat = parseFloat(chip.dataset.lat);
      const lng = parseFloat(chip.dataset.lng);
      const name = chip.dataset.name;

      map.flyTo({ center: [lng, lat], zoom: 14.5, speed: 1.4 });
      setMapMarker(lat, lng);
      fetchLocationScore(lat, lng, name);
    });
  });

  // Toggle Weekday vs Weekend
  document.getElementById("toggle-weekday").addEventListener("click", () => {
    document.getElementById("toggle-weekday").classList.add("active");
    document.getElementById("toggle-weekend").classList.remove("active");
    selectedDayType = "weekday";
    if (activeScoreData) renderChart(activeScoreData);
    fetchHeatmapPoints();
  });

  document.getElementById("toggle-weekend").addEventListener("click", () => {
    document.getElementById("toggle-weekend").classList.add("active");
    document.getElementById("toggle-weekday").classList.remove("active");
    selectedDayType = "weekend";
    if (activeScoreData) renderChart(activeScoreData);
    fetchHeatmapPoints();
  });

  // Map Time-of-Day Filter Pills
  document.querySelectorAll(".map-tod-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".map-tod-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      selectedTimeOfDay = btn.dataset.tod;
      fetchHeatmapPoints();
    });
  });

  // Log Noise Button
  document.getElementById("log-noise-btn").addEventListener("click", startMicMetering);
  document.getElementById("cancel-mic-btn").addEventListener("click", stopMicMetering);

  // DOT Federal Layer Toggle
  const dotToggleBtn = document.getElementById("dot-layer-toggle");
  if (dotToggleBtn) {
    dotToggleBtn.addEventListener("click", toggleDotLayer);
  }

  // Tag Selector Options in Modal
  document.querySelectorAll(".tag-option").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tag-option").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
    });
  });

  // Submit Report
  document.getElementById("submit-report-btn").addEventListener("click", submitNoiseReport);
}

// Address Search using Nominatim / Mapbox Geocoding
async function handleAddressSearch(query) {
  if (!query || !query.trim()) return;

  try {
    const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query + ', Tamil Nadu')}`;
    const res = await fetch(url);
    const data = await res.json();

    if (data && data.length > 0) {
      const first = data[0];
      const lat = parseFloat(first.lat);
      const lng = parseFloat(first.lon);

      map.flyTo({ center: [lng, lat], zoom: 15, speed: 1.4 });
      setMapMarker(lat, lng);
      fetchLocationScore(lat, lng, first.display_name.split(',')[0]);
    } else {
      showToast("Location not found in Tamil Nadu. Try searching a major district or city.");
    }
  } catch (err) {
    console.error("Geocoding error:", err);
  }
}

// Web Audio API Microphone Decibel Metering
async function startMicMetering() {
  const modal = document.getElementById("mic-modal");
  const liveDisplay = document.getElementById("live-db-display");
  const micTagStep = document.getElementById("mic-tag-step");

  modal.classList.remove("hidden");
  micTagStep.classList.add("hidden");
  isMetering = true;

  try {
    mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const source = audioContext.createMediaStreamSource(mediaStream);
    analyserNode = audioContext.createAnalyser();
    analyserNode.fftSize = 256;
    source.connect(analyserNode);

    const bufferLength = analyserNode.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    let samples = [];
    const startTime = Date.now();

    const analyze = () => {
      if (!isMetering) return;

      analyserNode.getByteTimeDomainData(dataArray);

      let sum = 0;
      for (let i = 0; i < bufferLength; i++) {
        const v = (dataArray[i] - 128) / 128.0;
        sum += v * v;
      }
      const rms = Math.sqrt(sum / bufferLength);

      let db = Math.round(40 + rms * 120);
      db = Math.min(Math.max(db, 32), 105);

      liveDisplay.textContent = db;
      samples.push(db);

      if (Date.now() - startTime < 3000) {
        requestAnimationFrame(analyze);
      } else {
        recordedDb = Math.round(samples.reduce((a, b) => a + b, 0) / samples.length);
        liveDisplay.textContent = recordedDb;
        stopAudioStream();
        micTagStep.classList.remove("hidden");
      }
    };

    analyze();
  } catch (err) {
    console.error("Microphone access error:", err);
    showToast("Mic permission fallback: simulating live ambient metering...");
    simulateMicMetering();
  }
}

function simulateMicMetering() {
  const liveDisplay = document.getElementById("live-db-display");
  const micTagStep = document.getElementById("mic-tag-step");

  let count = 0;
  const interval = setInterval(() => {
    const simDb = Math.floor(52 + Math.random() * 25);
    liveDisplay.textContent = simDb;
    count++;
    if (count >= 15) {
      clearInterval(interval);
      recordedDb = Math.floor(58 + Math.random() * 18);
      liveDisplay.textContent = recordedDb;
      micTagStep.classList.remove("hidden");
    }
  }, 200);
}

function stopAudioStream() {
  if (mediaStream) {
    mediaStream.getTracks().forEach(track => track.stop());
    mediaStream = null;
  }
  if (audioContext) {
    audioContext.close();
    audioContext = null;
  }
}

function stopMicMetering() {
  isMetering = false;
  stopAudioStream();
  document.getElementById("mic-modal").classList.add("hidden");
}

// Submit Crowdsourced Noise Report to Backend
async function submitNoiseReport() {
  const activeTagBtn = document.querySelector(".tag-option.active");
  const selectedTag = activeTagBtn ? activeTagBtn.dataset.tag : "other";

  const payload = {
    lat: currentLat,
    lng: currentLng,
    decibel_estimate: recordedDb,
    tag: selectedTag,
    source: "crowdsourced"
  };

  try {
    const headers = { "Content-Type": "application/json" };
    const token = localStorage.getItem("noisecheck_token");
    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }

    const res = await fetch(`${API_BASE}/reports`, {
      method: "POST",
      headers: headers,
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      stopMicMetering();
      showToast(`Recorded ${recordedDb} dB report in Tamil Nadu dataset!`);
      fetchHeatmapPoints();
      fetchLocationScore(currentLat, currentLng, "Updated Location Score");
    } else {
      showToast("Error submitting report. Please try again.");
    }
  } catch (err) {
    console.error("Report submit error:", err);
    showToast("Failed to connect to backend server.");
  }
}

// Show Toast Notification
function showToast(msg) {
  const toast = document.getElementById("toast");
  document.getElementById("toast-msg").textContent = msg;
  toast.classList.remove("hidden");
  setTimeout(() => {
    toast.classList.add("hidden");
  }, 3500);
}

// ==========================================
// User Authentication & Dashboard Logic
// ==========================================

function initAuth() {
  updateAuthUI();

  // Overlay Close Buttons
  document.querySelectorAll(".close-overlay-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.getElementById("auth-overlay").classList.add("hidden");
      document.getElementById("register-card").classList.add("hidden");
      document.getElementById("login-card").classList.add("hidden");
      document.getElementById("dashboard-card").classList.add("hidden");
    });
  });

  // Nav Buttons
  document.getElementById("nav-login-btn").addEventListener("click", () => showAuthOverlay("login"));
  document.getElementById("nav-register-btn").addEventListener("click", () => showAuthOverlay("register"));
  document.getElementById("nav-dashboard-btn").addEventListener("click", () => {
    showAuthOverlay("dashboard");
    fetchMyReports();
  });
  document.getElementById("nav-logout-btn").addEventListener("click", () => {
    localStorage.removeItem("noisecheck_token");
    updateAuthUI();
    showToast("Successfully signed out");
  });

  // Switch Links
  document.getElementById("switch-to-login").addEventListener("click", (e) => {
    e.preventDefault();
    showAuthOverlay("login");
  });
  document.getElementById("switch-to-register").addEventListener("click", (e) => {
    e.preventDefault();
    showAuthOverlay("register");
  });

  // Forms
  document.getElementById("register-form").addEventListener("submit", handleRegister);
  document.getElementById("login-form").addEventListener("submit", handleLogin);

  // Dashboard log new reading button
  document.getElementById("dash-log-new-btn").addEventListener("click", () => {
    document.getElementById("auth-overlay").classList.add("hidden");
    document.getElementById("dashboard-card").classList.add("hidden");
  });
}

function updateAuthUI() {
  const token = localStorage.getItem("noisecheck_token");
  if (token) {
    document.getElementById("auth-logged-out").classList.add("hidden");
    document.getElementById("auth-logged-in").classList.remove("hidden");
    
    // Fetch user info to populate name
    fetch(`${API_BASE}/auth/me`, {
      headers: { "Authorization": `Bearer ${token}` }
    })
    .then(res => {
      if (res.ok) return res.json();
      throw new Error("Invalid token");
    })
    .then(data => {
      document.getElementById("nav-user-name").textContent = data.display_name;
      document.getElementById("dashboard-welcome").textContent = `Welcome, ${data.display_name}`;
    })
    .catch(() => {
      // Token invalid or expired
      localStorage.removeItem("noisecheck_token");
      document.getElementById("auth-logged-out").classList.remove("hidden");
      document.getElementById("auth-logged-in").classList.add("hidden");
    });
  } else {
    document.getElementById("auth-logged-out").classList.remove("hidden");
    document.getElementById("auth-logged-in").classList.add("hidden");
  }
}

function showAuthOverlay(view) {
  document.getElementById("auth-overlay").classList.remove("hidden");
  document.getElementById("register-card").classList.add("hidden");
  document.getElementById("login-card").classList.add("hidden");
  document.getElementById("dashboard-card").classList.add("hidden");
  
  // Clear errors
  document.getElementById("reg-error").classList.add("hidden");
  document.getElementById("login-error").classList.add("hidden");

  document.getElementById(`${view}-card`).classList.remove("hidden");
}

async function handleRegister(e) {
  e.preventDefault();
  const name = document.getElementById("reg-name").value;
  const email = document.getElementById("reg-email").value;
  const password = document.getElementById("reg-password").value;
  const confirm = document.getElementById("reg-confirm").value;
  const errorEl = document.getElementById("reg-error");

  if (password !== confirm) {
    errorEl.textContent = "Passwords do not match";
    errorEl.classList.remove("hidden");
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, display_name: name })
    });

    const data = await res.json();
    if (res.ok) {
      localStorage.setItem("noisecheck_token", data.access_token);
      updateAuthUI();
      showAuthOverlay("dashboard");
      fetchMyReports();
      showToast("Registration successful!");
    } else {
      errorEl.textContent = data.detail || "Registration failed";
      errorEl.classList.remove("hidden");
    }
  } catch (err) {
    errorEl.textContent = "Connection error";
    errorEl.classList.remove("hidden");
  }
}

async function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById("login-email").value;
  const password = document.getElementById("login-password").value;
  const errorEl = document.getElementById("login-error");

  try {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();
    if (res.ok) {
      localStorage.setItem("noisecheck_token", data.access_token);
      updateAuthUI();
      showAuthOverlay("dashboard");
      fetchMyReports();
      showToast("Signed in successfully");
    } else {
      errorEl.textContent = data.detail || "Invalid email or password";
      errorEl.classList.remove("hidden");
    }
  } catch (err) {
    errorEl.textContent = "Connection error";
    errorEl.classList.remove("hidden");
  }
}

async function fetchMyReports() {
  const token = localStorage.getItem("noisecheck_token");
  if (!token) return;

  try {
    const res = await fetch(`${API_BASE}/users/me/reports`, {
      headers: { "Authorization": `Bearer ${token}` }
    });

    if (res.ok) {
      const reports = await res.json();
      document.getElementById("dash-total-reports").textContent = reports.length;
      
      const tbody = document.getElementById("dashboard-reports-list");
      const emptyState = document.getElementById("dash-empty-state");
      tbody.innerHTML = "";

      if (reports.length === 0) {
        emptyState.classList.remove("hidden");
      } else {
        emptyState.classList.add("hidden");
        reports.forEach(r => {
          const dt = new Date(r.timestamp);
          const tr = document.createElement("tr");
          tr.innerHTML = `
            <td>${dt.toLocaleDateString()} ${dt.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</td>
            <td>${r.lat.toFixed(4)}, ${r.lng.toFixed(4)}</td>
            <td><strong>${r.decibel_estimate.toFixed(1)} dB</strong></td>
            <td style="text-transform: capitalize;">${r.tag}</td>
          `;
          tbody.appendChild(tr);
        });
      }
    }
  } catch (err) {
    console.error("Failed to fetch user reports", err);
  }
}
