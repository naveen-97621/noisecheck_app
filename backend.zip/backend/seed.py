import os
import random
import datetime
import httpx
from dotenv import load_dotenv
from sqlalchemy.orm import Session
import models
from database import SessionLocal, engine, Base

load_dotenv()

GOOGLE_PLACES_API_KEY = os.getenv("GOOGLE_PLACES_API_KEY", "")


def generate_seed_reports_for_poi(
    lat: float, lng: float, poi_type: str, name: str
) -> list:
    """
    Generates realistic temporal noise readings (morning, afternoon, evening, night for weekday & weekend)
    for a given POI based on its noise risk heuristic.
    """
    reports = []
    now = datetime.datetime.utcnow()

    # We generate readings for different synthetic timestamps across a typical week
    # Base timestamps:
    # 1. Weekday Morning (e.g. Wed 08:30)
    # 2. Weekday Afternoon (e.g. Wed 14:00)
    # 3. Weekday Evening (e.g. Wed 19:30)
    # 4. Weekday Night (e.g. Wed 23:30)
    # 5. Weekend Afternoon (e.g. Sat 15:00)
    # 6. Weekend Night (e.g. Sat 23:45)

    timestamps = [
        (datetime.datetime(2026, 7, 22, 8, 30), "weekday_morning"),
        (datetime.datetime(2026, 7, 22, 14, 0), "weekday_afternoon"),
        (datetime.datetime(2026, 7, 22, 19, 30), "weekday_evening"),
        (datetime.datetime(2026, 7, 22, 23, 30), "weekday_night"),
        (datetime.datetime(2026, 7, 25, 15, 0), "weekend_afternoon"),
        (datetime.datetime(2026, 7, 25, 23, 45), "weekend_night"),
        (datetime.datetime(2026, 7, 26, 1, 30), "weekend_late_night"),
    ]

    for dt, period in timestamps:
        base_db = 42.0 + random.uniform(-2.0, 2.0)
        tag = "other"

        if poi_type in ("bar", "night_club", "nightlife"):
            tag = "nightlife"
            if period in ("weekend_night", "weekend_late_night"):
                db_value = base_db + random.uniform(32.0, 42.0)  # ~74-84 dB
            elif period in ("weekday_night", "weekday_evening"):
                db_value = base_db + random.uniform(20.0, 30.0)  # ~62-72 dB
            else:
                db_value = base_db + random.uniform(2.0, 8.0)  # ~44-50 dB

        elif poi_type in ("transit_station", "train_station", "subway_station", "trains"):
            tag = "trains"
            if period in ("weekday_morning", "weekday_evening"):
                db_value = base_db + random.uniform(28.0, 38.0)  # ~70-80 dB (rush hour)
            elif period in ("weekday_afternoon", "weekend_afternoon"):
                db_value = base_db + random.uniform(15.0, 25.0)  # ~57-67 dB
            else:
                db_value = base_db + random.uniform(5.0, 12.0)  # ~47-54 dB

        elif poi_type in ("traffic", "highway", "bus_station"):
            tag = "traffic"
            if period in ("weekday_morning", "weekday_evening"):
                db_value = base_db + random.uniform(25.0, 35.0)  # ~67-77 dB
            elif period in ("weekday_afternoon", "weekend_afternoon"):
                db_value = base_db + random.uniform(18.0, 26.0)  # ~60-68 dB
            else:
                db_value = base_db + random.uniform(8.0, 16.0)  # ~50-58 dB

        elif poi_type in ("construction"):
            tag = "construction"
            if period in ("weekday_morning", "weekday_afternoon"):
                db_value = base_db + random.uniform(35.0, 48.0)  # ~77-90 dB
            else:
                db_value = base_db + random.uniform(0.0, 4.0)  # ~42-46 dB
        else:
            db_value = base_db + random.uniform(2.0, 10.0)

        # Scatter points slightly within ~100m around the POI center
        lat_offset = random.uniform(-0.0008, 0.0008)
        lng_offset = random.uniform(-0.0008, 0.0008)

        report = models.NoiseReport(
            lat=round(lat + lat_offset, 6),
            lng=round(lng + lng_offset, 6),
            decibel_estimate=round(db_value, 1),
            timestamp=dt,
            tag=tag,
            source="seed",
        )
        reports.append(report)

    return reports


def fetch_google_places_pois(lat: float, lng: float, radius: int = 1500) -> list:
    """
    Fetch POIs using Google Places Nearby Search API
    """
    if not GOOGLE_PLACES_API_KEY:
        print("[SEED] Warning: GOOGLE_PLACES_API_KEY not set in .env. Using mock POIs.")
        return []

    url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"
    types_to_fetch = ["bar", "night_club", "transit_station", "train_station"]
    all_pois = []

    with httpx.Client() as client:
        for ptype in types_to_fetch:
            params = {
                "location": f"{lat},{lng}",
                "radius": radius,
                "type": ptype,
                "key": GOOGLE_PLACES_API_KEY,
            }
            try:
                res = client.get(url, params=params, timeout=10.0)
                data = res.json()
                if data.get("status") == "OK":
                    for item in data.get("results", [])[:5]:  # Top 5 per category
                        loc = item["geometry"]["location"]
                        all_pois.append({
                            "lat": loc["lat"],
                            "lng": loc["lng"],
                            "type": ptype,
                            "name": item.get("name", ptype),
                        })
            except Exception as e:
                print(f"[SEED] Error fetching Google Places for {ptype}: {e}")

    return all_pois


def get_fallback_mock_pois(center_lat: float = 40.730610, center_lng: float = -73.935242) -> list:
    """
    Provides mock POIs around NYC / demo city if no Google Places API key is configured.
    """
    return [
        # Nightlife cluster (e.g. East Village / Williamsburg strip)
        {"lat": center_lat + 0.002, "lng": center_lng - 0.003, "type": "bar", "name": "The Neon Lounge Bar"},
        {"lat": center_lat + 0.0025, "lng": center_lng - 0.0028, "type": "night_club", "name": "Club Pulse"},
        {"lat": center_lat + 0.0018, "lng": center_lng - 0.0035, "type": "bar", "name": "Speakeasy Tavern"},

        # Transit Hub (e.g. Central Station / Subway Stop)
        {"lat": center_lat - 0.004, "lng": center_lng + 0.002, "type": "transit_station", "name": "Metro Transit Station"},
        {"lat": center_lat - 0.0042, "lng": center_lng + 0.0025, "type": "train_station", "name": "Central Railway Junction"},

        # Highway / Busy Avenue
        {"lat": center_lat + 0.005, "lng": center_lng + 0.005, "type": "traffic", "name": "Grand Avenue Highway"},
        {"lat": center_lat + 0.0055, "lng": center_lng + 0.0048, "type": "traffic", "name": "Expressway Intersection"},

        # Construction Site
        {"lat": center_lat - 0.001, "lng": center_lng - 0.005, "type": "construction", "name": "Downtown Condo Build"},

        # Quiet Residential Block
        {"lat": center_lat - 0.006, "lng": center_lng - 0.006, "type": "other", "name": "Greenwood Quiet Residential"},
    ]


def run_seeding(center_lat: float = 40.730610, center_lng: float = -73.935242, radius: int = 2000):
    Base.metadata.create_all(bind=engine)
    db: Session = SessionLocal()

    print(f"[SEED] Starting seed generation for center ({center_lat}, {center_lng})...")
    pois = fetch_google_places_pois(center_lat, center_lng, radius)

    if not pois:
        print("[SEED] Using mock POI dataset for demo area...")
        pois = get_fallback_mock_pois(center_lat, center_lng)

    total_inserted = 0
    for poi in pois:
        seed_reports = generate_seed_reports_for_poi(
            poi["lat"], poi["lng"], poi["type"], poi["name"]
        )
        for r in seed_reports:
            db.add(r)
            total_inserted += 1

    db.commit()
    db.close()
    print(f"[SEED] Successfully inserted {total_inserted} seed noise reports into database!")


if __name__ == "__main__":
    # Default seed center: NYC Manhattan / East Village
    run_seeding()
