import os
from typing import List, Optional
from fastapi import FastAPI, Depends, Query, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

import models
import schemas
import crud
import auth
from database import engine, get_db
from dot_noise_service import get_dot_noise_db

# Create database tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="NoiseCheck — Tamil Nadu Noise Intelligence Platform",
    description="API for state-wide noise level estimations, heatmap scores, and audio metering logs across Tamil Nadu.",
    version="2.0.0",
)

# Enable CORS for frontend development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

FRONTEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend"))

# Static files & main page serving
@app.get("/")
def read_root():
    index_path = os.path.join(FRONTEND_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "NoiseCheck API is online. Use /score or /reports endpoints."}

@app.get("/style.css")
def get_css():
    css_path = os.path.join(FRONTEND_DIR, "style.css")
    return FileResponse(css_path, media_type="text/css")

@app.get("/app.js")
def get_js():
    js_path = os.path.join(FRONTEND_DIR, "app.js")
    return FileResponse(js_path, media_type="application/javascript")

@app.get("/tn_districts.json")
def get_tn_districts():
    geojson_path = os.path.join(FRONTEND_DIR, "tn_districts.json")
    return FileResponse(geojson_path, media_type="application/json")


# API Endpoints
@app.post("/reports", response_model=schemas.NoiseReportResponse)
def create_report(
    report: schemas.NoiseReportCreate, 
    db: Session = Depends(get_db),
    current_user: Optional[models.User] = Depends(auth.get_optional_user)
):
    """
    Log a new noise report.
    Guest logging is permitted (no auth required).
    If a valid JWT is provided, the report will be associated with the user's ID.
    """
    if current_user:
        report.user_id = current_user.id

    return crud.create_report(db, report)


# --- Authentication & User Routes ---

@app.post("/auth/register", response_model=schemas.Token)
def register_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_email(db, email=user.email)
    if db_user:
        raise HTTPException(status_code=409, detail="Email already registered")
    
    new_user = crud.create_user(db, user)
    access_token = auth.create_access_token(data={"sub": new_user.email})
    return {"access_token": access_token, "token_type": "bearer"}


@app.post("/auth/login", response_model=schemas.Token)
def login_user(user: schemas.UserLogin, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_email(db, email=user.email)
    
    # Generic error message to prevent user enumeration
    generic_error = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid email or password",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    if not db_user:
        raise generic_error
    if not auth.verify_password(user.password, db_user.password_hash):
        raise generic_error
        
    access_token = auth.create_access_token(data={"sub": db_user.email})
    return {"access_token": access_token, "token_type": "bearer"}


@app.get("/auth/me", response_model=schemas.UserResponse)
def read_users_me(current_user: models.User = Depends(auth.get_current_user)):
    return current_user


@app.get("/users/me/reports", response_model=List[schemas.NoiseReportResponse])
def read_my_reports(
    db: Session = Depends(get_db), 
    current_user: models.User = Depends(auth.get_current_user)
):
    """
    Get all noise reports submitted by the logged-in user.
    """
    return crud.get_reports_by_user(db, user_id=current_user.id)


@app.get("/reports", response_model=List[schemas.NoiseReportResponse])
def get_reports(
    lat: Optional[float] = Query(None, description="Latitude of location center"),
    lng: Optional[float] = Query(None, description="Longitude of location center"),
    radius: float = Query(2000.0, description="Radius in meters (default 2000m)"),
    min_lat: Optional[float] = Query(None, description="Bounding box min latitude"),
    max_lat: Optional[float] = Query(None, description="Bounding box max latitude"),
    min_lng: Optional[float] = Query(None, description="Bounding box min longitude"),
    max_lng: Optional[float] = Query(None, description="Bounding box max longitude"),
    day_type: Optional[str] = Query("all", description="Filter by day type: weekday | weekend | all"),
    time_of_day: Optional[str] = Query("all", description="Filter by time of day: morning | afternoon | evening | night | all"),
    limit: int = Query(3500, description="Max records to return"),
    db: Session = Depends(get_db),
):
    """
    Get noise reports matching spatial bounding box / radius and optional temporal filters.
    """
    return crud.get_reports_in_bounds(
        db,
        lat=lat,
        lng=lng,
        radius_meters=radius,
        min_lat=min_lat,
        max_lat=max_lat,
        min_lng=min_lng,
        max_lng=max_lng,
        day_type=day_type,
        time_of_day=time_of_day,
        limit=limit,
    )


@app.get("/score", response_model=schemas.NoiseScoreResponse)
def get_noise_score(
    lat: float = Query(..., description="Latitude of location center"),
    lng: float = Query(..., description="Longitude of location center"),
    radius: float = Query(500.0, description="Radius in meters (default 500m)"),
    db: Session = Depends(get_db),
):
    """
    Get aggregated noise score & decibel profile (time of day, day of week) for a location.
    Also enriches response with DOT NTAD 2020 federal transportation noise baseline where available.
    """
    result = crud.calculate_noise_score(db, lat=lat, lng=lng, radius_meters=radius)
    result_dict = result.model_dump()

    # Enrich with US DOT federal baseline (non-blocking on failure)
    try:
        dot_db = get_dot_noise_db(lat, lng)
        result_dict["dot_baseline_db"] = dot_db
    except Exception:
        result_dict["dot_baseline_db"] = None

    return result_dict


@app.get("/dot-noise", response_model=schemas.DotNoiseResponse)
def get_dot_noise(
    lat: float = Query(..., description="Latitude"),
    lng: float = Query(..., description="Longitude"),
):
    """
    Query the US DOT NTAD 2020 National Transportation Noise Map for a coordinate.
    Returns the modeled 24-hour LAeq dB value from the federal dataset.

    Data covers: highway, rail, and aviation noise only (CONUS coverage).
    NOT suitable for individual-location regulatory purposes.
    Single 24-hour daily average only — no time-of-day breakdown.
    """
    dot_db = get_dot_noise_db(lat, lng)
    return schemas.DotNoiseResponse(
        lat=lat,
        lng=lng,
        dot_baseline_db=dot_db,
        data_available=dot_db is not None,
    )


@app.post("/seed")
def trigger_seeding(
    lat: float = Query(11.1271, description="Center latitude"),
    lng: float = Query(78.6569, description="Center longitude"),
    radius: int = Query(2000, description="Search radius in meters"),
):
    """
    Trigger seed report generation around a location (Google Places or Mock POI).
    """
    import seed_tn
    seed_tn.generate_tn_seed_data()
    return {"status": "success", "message": "Seeded Tamil Nadu noise intelligence dataset"}
