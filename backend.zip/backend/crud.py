import math
from datetime import datetime
from collections import Counter
from typing import List, Dict, Tuple, Optional
from sqlalchemy.orm import Session
import models
import schemas
import auth


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculate the great circle distance in meters between two points
    """
    R = 6371000.0  # Earth radius in meters
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2.0) ** 2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2.0) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


def get_reports_in_bounds(
    db: Session,
    lat: Optional[float] = None,
    lng: Optional[float] = None,
    radius_meters: float = 2000.0,
    min_lat: Optional[float] = None,
    max_lat: Optional[float] = None,
    min_lng: Optional[float] = None,
    max_lng: Optional[float] = None,
    day_type: Optional[str] = "all",
    time_of_day: Optional[str] = "all",
    limit: int = 3500,
) -> List[models.NoiseReport]:

    """
    Returns noise reports matching spatial bounding box / radius and optional temporal filters.
    """
    query = db.query(models.NoiseReport)

    if min_lat is not None and max_lat is not None and min_lng is not None and max_lng is not None:
        query = query.filter(
            models.NoiseReport.lat >= min_lat,
            models.NoiseReport.lat <= max_lat,
            models.NoiseReport.lng >= min_lng,
            models.NoiseReport.lng <= max_lng,
        )
    elif lat is not None and lng is not None:
        lat_delta = radius_meters / 111000.0
        cos_lat = math.cos(math.radians(lat))
        lng_delta = radius_meters / (111000.0 * max(cos_lat, 0.01))
        query = query.filter(
            models.NoiseReport.lat >= lat - lat_delta,
            models.NoiseReport.lat <= lat + lat_delta,
            models.NoiseReport.lng >= lng - lng_delta,
            models.NoiseReport.lng <= lng + lng_delta,
        )

    all_candidates = query.limit(limit * 2).all()

    # Temporal & Radius Filtering
    filtered = []
    for rep in all_candidates:
        if lat is not None and lng is not None and min_lat is None:
            if haversine_distance(lat, lng, rep.lat, rep.lng) > radius_meters:
                continue

        dt = rep.timestamp or datetime.utcnow()

        # Day of week filter
        is_weekend = dt.weekday() in (5, 6)
        if day_type == "weekday" and is_weekend:
            continue
        if day_type == "weekend" and not is_weekend:
            continue

        # Time of day filter
        hr = dt.hour
        if 6 <= hr < 12:
            tod = "morning"
        elif 12 <= hr < 18:
            tod = "afternoon"
        elif 18 <= hr < 22:
            tod = "evening"
        else:
            tod = "night"

        if time_of_day and time_of_day != "all" and tod != time_of_day:
            continue

        filtered.append(rep)

        if len(filtered) >= limit:
            break

    return filtered


def get_reports_near(
    db: Session, lat: float, lng: float, radius_meters: float = 500.0
) -> List[models.NoiseReport]:
    return get_reports_in_bounds(db, lat=lat, lng=lng, radius_meters=radius_meters, limit=500)


def calculate_noise_score(
    db: Session, lat: float, lng: float, radius_meters: float = 500.0
) -> schemas.NoiseScoreResponse:
    reports = get_reports_near(db, lat, lng, radius_meters)

    if not reports:
        return schemas.NoiseScoreResponse(
            lat=lat,
            lng=lng,
            radius_meters=radius_meters,
            overall_db=45.0,
            overall_score_1_to_5=2,
            time_of_day=schemas.TimeOfDayBreakdown(
                morning=42.0, afternoon=45.0, evening=44.0, night=40.0
            ),
            day_of_week=schemas.DayOfWeekBreakdown(weekday=44.0, weekend=42.0),
            top_tags=["residential"],
            report_count=0,
        )

    tod_buckets = {"morning": [], "afternoon": [], "evening": [], "night": []}
    dow_buckets = {"weekday": [], "weekend": []}
    tags_counter = Counter()

    for r in reports:
        tags_counter[r.tag] += 1
        dt = r.timestamp or datetime.utcnow()

        if dt.weekday() in (5, 6):
            dow_buckets["weekend"].append(r.decibel_estimate)
        else:
            dow_buckets["weekday"].append(r.decibel_estimate)

        hr = dt.hour
        if 6 <= hr < 12:
            tod_buckets["morning"].append(r.decibel_estimate)
        elif 12 <= hr < 18:
            tod_buckets["afternoon"].append(r.decibel_estimate)
        elif 18 <= hr < 22:
            tod_buckets["evening"].append(r.decibel_estimate)
        else:
            tod_buckets["night"].append(r.decibel_estimate)

    def avg_or_default(lst: List[float], default: float) -> float:
        if not lst:
            return default
        return round(sum(lst) / len(lst), 1)

    all_dbs = [r.decibel_estimate for r in reports]
    overall_db = round(sum(all_dbs) / len(all_dbs), 1)

    morning_avg = avg_or_default(tod_buckets["morning"], overall_db)
    afternoon_avg = avg_or_default(tod_buckets["afternoon"], overall_db)
    evening_avg = avg_or_default(tod_buckets["evening"], overall_db)
    night_avg = avg_or_default(tod_buckets["night"], overall_db)

    weekday_avg = avg_or_default(dow_buckets["weekday"], overall_db)
    weekend_avg = avg_or_default(dow_buckets["weekend"], overall_db)

    if overall_db < 45.0:
        score_1_to_5 = 1
    elif overall_db < 55.0:
        score_1_to_5 = 2
    elif overall_db < 65.0:
        score_1_to_5 = 3
    elif overall_db < 75.0:
        score_1_to_5 = 4
    else:
        score_1_to_5 = 5

    top_tags = [tag for tag, _ in tags_counter.most_common(3)]

    return schemas.NoiseScoreResponse(
        lat=lat,
        lng=lng,
        radius_meters=radius_meters,
        overall_db=overall_db,
        overall_score_1_to_5=score_1_to_5,
        time_of_day=schemas.TimeOfDayBreakdown(
            morning=morning_avg,
            afternoon=afternoon_avg,
            evening=evening_avg,
            night=night_avg,
        ),
        day_of_week=schemas.DayOfWeekBreakdown(
            weekday=weekday_avg,
            weekend=weekend_avg,
        ),
        top_tags=top_tags,
        report_count=len(reports),
    )


def create_report(db: Session, report_in: schemas.NoiseReportCreate) -> models.NoiseReport:
    db_report = models.NoiseReport(
        lat=report_in.lat,
        lng=report_in.lng,
        decibel_estimate=report_in.decibel_estimate,
        timestamp=report_in.timestamp or datetime.utcnow(),
        tag=report_in.tag,
        source=report_in.source,
        user_id=report_in.user_id,
    )
    db.add(db_report)
    db.commit()
    db.refresh(db_report)
    return db_report


def get_user_by_email(db: Session, email: str) -> Optional[models.User]:
    return db.query(models.User).filter(models.User.email == email).first()


def create_user(db: Session, user: schemas.UserCreate) -> models.User:
    hashed_password = auth.get_password_hash(user.password)
    db_user = models.User(
        email=user.email,
        password_hash=hashed_password,
        display_name=user.display_name
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


def get_reports_by_user(db: Session, user_id: int) -> List[models.NoiseReport]:
    return db.query(models.NoiseReport).filter(models.NoiseReport.user_id == user_id).order_by(models.NoiseReport.timestamp.desc()).all()
