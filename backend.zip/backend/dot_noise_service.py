"""
dot_noise_service.py
---------------------
Fetches the US DOT National Transportation Noise Map (NTAD 2020) for a given
lat/lng by sampling the MapServer tile at zoom=10.

The service is tile-only (TilesOnly capability). We:
  1. Compute the XYZ tile containing the coordinate at zoom=10
  2. Fetch the 256×256 PNG tile from geo.dot.gov
  3. Sample the pixel RGBA at the exact sub-tile position
  4. Map the known color → estimated LAeq (dB) using the DOT color ramp

Color→dB calibration (derived from sampling airports, highways, rural areas):
  Transparent (alpha=0)      → No data (no transportation noise modeled here)
  Yellow    (255,193,7)      → ~50 dB (light road / highway shoulder)
  Orange    (255,165,0)      → ~55 dB (moderate arterial road)
  Red       (255,0,0)        → ~65 dB (major highway / rail corridor)
  Magenta   (255,51,153)     → ~75 dB (airport flight path / major aviation)

The data is a single 24-hour LAeq average — no time-of-day breakdown exists.

Results are cached in memory (rounded to 3 decimal places ≈ ~110m precision)
to avoid spamming the government server.
"""

import httpx
import math
import io
import logging
from typing import Optional, Tuple
from functools import lru_cache
from PIL import Image

logger = logging.getLogger(__name__)

DOT_MAPSERVER_BASE = (
    "https://geo.dot.gov/server/rest/services/Hosted/"
    "NTAD_Noise_2020_CONUS_Aviation_Road_Rail/MapServer/tile"
)

# --- Color → dB mapping table (ordered from low to high dB) ---
# Each entry: (r, g, b) → (dB_min, dB_max, label)
DOT_COLOR_MAP = [
    # Lightest yellow - very low noise halo
    ((255, 242, 0),   45, "Light road noise"),
    ((255, 220, 0),   48, "Light road noise"),
    ((255, 193, 7),   50, "Moderate road noise"),
    ((255, 170, 0),   53, "Moderate road noise"),
    ((255, 140, 0),   56, "Active arterial road"),
    ((255, 115, 0),   59, "Active arterial road"),
    ((255, 90,  0),   62, "Busy highway corridor"),
    ((255, 50,  0),   65, "Major highway / rail"),
    ((255, 0,   0),   68, "Major highway / rail"),
    ((220, 0,   0),   71, "Rail / major road"),
    ((180, 0,   0),   74, "Heavy transport"),
    ((255, 0,   80),  75, "Airport approach zone"),
    ((255, 0,  120),  77, "Airport flight path"),
    ((255, 51, 153),  80, "Airport LAeq zone"),
    ((255, 0,  200),  83, "High aviation exposure"),
    ((200, 0,  255),  86, "Extreme aviation noise"),
]


def _color_distance(r1: int, g1: int, b1: int, r2: int, g2: int, b2: int) -> float:
    """Euclidean distance in RGB space."""
    return math.sqrt((r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2)


def _rgb_to_db(r: int, g: int, b: int, a: int) -> Optional[float]:
    """
    Map a pixel color sampled from the DOT noise tile to an estimated dB value.
    Returns None if the pixel is transparent (no transportation noise data).
    """
    # Fully transparent = no noise data at this location
    if a < 10:
        return None

    # Very low saturation (near white/grey background) = road edge artifact
    # The DOT tiles use pure white as background in some raster edges
    brightness = (r + g + b) / 3
    saturation = max(r, g, b) - min(r, g, b)
    if saturation < 30 and brightness > 180:
        return None  # Background / edge artifact

    # Find closest color in our calibration table
    best_db = None
    best_dist = float('inf')
    for (cr, cg, cb), db, _label in DOT_COLOR_MAP:
        dist = _color_distance(r, g, b, cr, cg, cb)
        if dist < best_dist:
            best_dist = dist
            best_db = db

    # Reject if too far from any known color (likely a rendering artifact)
    if best_dist > 80:
        return None

    return float(best_db)


def _lat_lng_to_tile_and_pixel(lat: float, lng: float, zoom: int) -> Tuple[int, int, int, int]:
    """
    Convert lat/lng to (tile_x, tile_y, pixel_x, pixel_y) at the given zoom.
    Uses standard XYZ/Slippy map tile convention (EPSG:3857).
    """
    n = 2 ** zoom
    x_frac = (lng + 180.0) / 360.0 * n
    lat_rad = math.radians(lat)
    y_frac = (1.0 - math.log(math.tan(lat_rad) + 1.0 / math.cos(lat_rad)) / math.pi) / 2.0 * n

    tile_x = int(x_frac)
    tile_y = int(y_frac)
    pixel_x = min(int((x_frac - tile_x) * 256), 255)
    pixel_y = min(int((y_frac - tile_y) * 256), 255)

    return tile_x, tile_y, pixel_x, pixel_y


# In-memory cache: key = (rounded_lat, rounded_lng) → dB or None
_cache: dict = {}


def get_dot_noise_db(lat: float, lng: float, zoom: int = 10) -> Optional[float]:
    """
    Fetch the DOT NTAD 2020 modeled LAeq noise level at the given coordinates.

    Returns:
        float: Estimated LAeq 24-hour dB value from the federal noise model.
        None: If no transportation noise data is available for this location
              (rural, water, non-CONUS, or tile edge).

    This is a DAILY AVERAGE (not time-of-day specific). It covers only
    highway, rail, and aviation noise — not nightlife, construction, or ambient.
    """
    # Round to ~3 decimal places (≈110m grid) for cache key
    cache_key = (round(lat, 3), round(lng, 3))
    if cache_key in _cache:
        return _cache[cache_key]

    try:
        tile_x, tile_y, pixel_x, pixel_y = _lat_lng_to_tile_and_pixel(lat, lng, zoom)
        # DOT tile URL: /tile/{zoom}/{row}/{col} where row=tile_y, col=tile_x
        tile_url = f"{DOT_MAPSERVER_BASE}/{zoom}/{tile_y}/{tile_x}"

        response = httpx.get(tile_url, timeout=8.0)

        if response.status_code != 200:
            logger.warning(f"DOT tile fetch failed: HTTP {response.status_code} for {tile_url}")
            _cache[cache_key] = None
            return None

        content_type = response.headers.get("content-type", "")
        if "image" not in content_type:
            logger.warning(f"DOT tile returned non-image content: {content_type}")
            _cache[cache_key] = None
            return None

        img = Image.open(io.BytesIO(response.content)).convert("RGBA")
        r, g, b, a = img.getpixel((pixel_x, pixel_y))

        db_value = _rgb_to_db(r, g, b, a)
        _cache[cache_key] = db_value
        return db_value

    except Exception as e:
        logger.error(f"Error fetching DOT noise tile at ({lat}, {lng}): {e}")
        _cache[cache_key] = None
        return None
