from datetime import datetime
from typing import List, Optional
from enum import Enum
from pydantic import BaseModel, Field


class TagEnum(str, Enum):
    traffic = "traffic"
    construction = "construction"
    nightlife = "nightlife"
    trains = "trains"
    transportation = "transportation"  # DOT federal transportation noise
    other = "other"
    seed = "seed"


class SourceEnum(str, Enum):
    crowdsourced = "crowdsourced"
    passive = "passive"
    seed = "seed"
    dot_transportation = "dot_transportation"  # US DOT NTAD 2020 federal data


class NoiseReportCreate(BaseModel):
    lat: float
    lng: float
    decibel_estimate: float = Field(..., ge=30.0, le=130.0, description="Estimated decibel level between 30 and 130 dB")
    timestamp: Optional[datetime] = None
    tag: TagEnum
    source: SourceEnum = SourceEnum.crowdsourced
    user_id: Optional[int] = None


class NoiseReportResponse(BaseModel):
    id: int
    lat: float
    lng: float
    decibel_estimate: float
    timestamp: datetime
    tag: str
    source: str
    user_id: Optional[int] = None

    class Config:
        from_attributes = True


class TimeOfDayBreakdown(BaseModel):
    morning: float  # 6 - 12
    afternoon: float  # 12 - 18
    evening: float  # 18 - 22
    night: float  # 22 - 6


class DayOfWeekBreakdown(BaseModel):
    weekday: float
    weekend: float


class NoiseScoreResponse(BaseModel):
    lat: float
    lng: float
    radius_meters: float
    overall_db: float
    overall_score_1_to_5: int  # 1 (quietest) to 5 (loudest)
    time_of_day: TimeOfDayBreakdown
    day_of_week: DayOfWeekBreakdown
    top_tags: List[str]
    report_count: int
    dot_baseline_db: Optional[float] = None  # US DOT NTAD 2020 daily LAeq (null if no data)


class DotNoiseResponse(BaseModel):
    lat: float
    lng: float
    dot_baseline_db: Optional[float]  # 24-hr LAeq from US DOT NTAD 2020 (null = no data)
    data_available: bool
    source_note: str = (
        "US DOT NTAD 2020 National Transportation Noise Map — "
        "24-hour LAeq daily average covering highway, rail, and aviation noise only. "
        "Not suitable for individual-location regulatory use."
    )


# --- Auth & User Schemas ---

class UserCreate(BaseModel):
    email: str
    password: str = Field(..., min_length=8)
    display_name: str


class UserLogin(BaseModel):
    email: str
    password: str


class UserResponse(BaseModel):
    id: int
    email: str
    display_name: str
    created_at: datetime

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str
