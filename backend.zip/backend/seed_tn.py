import datetime
import random
from sqlalchemy.orm import Session
from database import SessionLocal, engine, Base
import models

def generate_tn_seed_data():
    Base.metadata.create_all(bind=engine)
    db: Session = SessionLocal()

    # Clear existing seed data if needed or add new
    print("[SEED TN] Generating Tamil Nadu geospatial noise dataset (~4,000 reports)...")

    # Defined Tamil Nadu key locations with typical noise profiles
    tn_locations = [
        # HIGH NOISE HOTSPOTS (65 - 92 dB)
        {"name": "Chennai Central Railway Station", "lat": 13.0827, "lng": 80.2707, "type": "high", "tag": "trains", "base_db": 76.0},
        {"name": "T Nagar Commercial Hub, Chennai", "lat": 13.0418, "lng": 80.2341, "type": "high", "tag": "traffic", "base_db": 74.0},
        {"name": "Marina Beach Promenade, Chennai", "lat": 13.0500, "lng": 80.2824, "type": "high", "tag": "nightlife", "base_db": 68.0},
        {"name": "Koyambedu Bus Terminal, Chennai", "lat": 13.0694, "lng": 80.1948, "type": "high", "tag": "traffic", "base_db": 78.0},
        {"name": "Gandhipuram Bus Stand, Coimbatore", "lat": 11.0168, "lng": 76.9558, "type": "high", "tag": "traffic", "base_db": 75.0},
        {"name": "Madurai Central Bus Stand", "lat": 9.9195, "lng": 78.1193, "type": "high", "tag": "traffic", "base_db": 73.0},
        {"name": "Tiruppur Textile Industrial Zone", "lat": 11.1085, "lng": 77.3411, "type": "high", "tag": "construction", "base_db": 77.0},
        {"name": "Salem Railway Junction", "lat": 11.6643, "lng": 78.1460, "type": "high", "tag": "trains", "base_db": 72.0},
        {"name": "Trichy Central Junction", "lat": 10.7905, "lng": 78.6946, "type": "high", "tag": "trains", "base_db": 71.0},
        {"name": "Guindy Industrial Estate, Chennai", "lat": 13.0067, "lng": 80.2020, "type": "high", "tag": "construction", "base_db": 75.0},

        # MEDIUM NOISE CITIES & TOWNS (50 - 68 dB)
        {"name": "Erode Bus Stand", "lat": 11.3410, "lng": 77.7172, "type": "medium", "tag": "traffic", "base_db": 62.0},
        {"name": "Vellore Fort Area", "lat": 12.9165, "lng": 79.1325, "type": "medium", "tag": "other", "base_db": 58.0},
        {"name": "Hosur Industrial Belt", "lat": 12.7409, "lng": 77.8253, "type": "medium", "tag": "construction", "base_db": 66.0},
        {"name": "Thanjavur Temple Circle", "lat": 10.7870, "lng": 79.1378, "type": "medium", "tag": "other", "base_db": 55.0},
        {"name": "Tirunelveli Junction", "lat": 8.7139, "lng": 77.7567, "type": "medium", "tag": "traffic", "base_db": 61.0},
        {"name": "Kanchipuram Silk Street", "lat": 12.8342, "lng": 79.7036, "type": "medium", "tag": "other", "base_db": 57.0},
        {"name": "Cuddalore Town Center", "lat": 11.7480, "lng": 79.7714, "type": "medium", "tag": "traffic", "base_db": 59.0},
        {"name": "Dindigul Bus Junction", "lat": 10.3673, "lng": 77.9803, "type": "medium", "tag": "traffic", "base_db": 63.0},
        {"name": "Nagercoil Central", "lat": 8.1833, "lng": 77.4119, "type": "medium", "tag": "other", "base_db": 56.0},
        {"name": "Karur Textile Hub", "lat": 10.9601, "lng": 78.0766, "type": "medium", "tag": "traffic", "base_db": 60.0},
        {"name": "Thoothukudi Port Zone", "lat": 8.7642, "lng": 78.1348, "type": "medium", "tag": "traffic", "base_db": 64.0},

        # LOW NOISE HILL STATIONS & NATURE RESERVES (32 - 46 dB)
        {"name": "Ooty Botanical Gardens", "lat": 11.4102, "lng": 76.6950, "type": "low", "tag": "other", "base_db": 38.0},
        {"name": "Kodaikanal Lake Promenade", "lat": 10.2381, "lng": 77.4892, "type": "low", "tag": "other", "base_db": 36.0},
        {"name": "Yercaud Lake Loop", "lat": 11.7753, "lng": 78.2093, "type": "low", "tag": "other", "base_db": 37.0},
        {"name": "Mudumalai Elephant Sanctuary", "lat": 11.5623, "lng": 76.5342, "type": "low", "tag": "other", "base_db": 34.0},
        {"name": "Pollachi Greenfield Suburb", "lat": 10.6609, "lng": 77.0048, "type": "low", "tag": "other", "base_db": 41.0},
        {"name": "Anaimalai Tiger Reserve Park", "lat": 10.5800, "lng": 76.9300, "type": "low", "tag": "other", "base_db": 33.0},
        {"name": "Valparai Tea Estates", "lat": 10.3267, "lng": 76.9554, "type": "low", "tag": "other", "base_db": 35.0},
        {"name": "Kourtallam Waterfalls Reserve", "lat": 8.9333, "lng": 77.2667, "type": "low", "tag": "other", "base_db": 42.0},
    ]

    # Synthetic timestamp generators for weekday/weekend & time of day
    base_timestamps = [
        # Weekday Morning (08:30)
        datetime.datetime(2026, 7, 22, 8, 30),
        # Weekday Afternoon (14:00)
        datetime.datetime(2026, 7, 22, 14, 0),
        # Weekday Evening (19:30)
        datetime.datetime(2026, 7, 22, 19, 30),
        # Weekday Night (23:30)
        datetime.datetime(2026, 7, 22, 23, 30),
        # Weekend Afternoon (15:00)
        datetime.datetime(2026, 7, 25, 15, 0),
        # Weekend Night (23:45)
        datetime.datetime(2026, 7, 25, 23, 45),
        # Weekend Late Night (01:30)
        datetime.datetime(2026, 7, 26, 1, 30),
    ]

    reports_buffer = []

    for loc in tn_locations:
        center_lat = loc["lat"]
        center_lng = loc["lng"]
        base_db = loc["base_db"]
        loc_type = loc["type"]
        tag = loc["tag"]

        # Determine points count per location cluster
        if loc_type == "high":
            cluster_count = 180  # ~180 points per high-noise hub
            scatter_radius = 0.035  # ~3.5 km spread
        elif loc_type == "medium":
            cluster_count = 110  # ~110 points
            scatter_radius = 0.045  # ~4.5 km spread
        else:
            cluster_count = 70   # ~70 points
            scatter_radius = 0.050  # ~5.0 km spread

        for _ in range(cluster_count):
            # Random scatter around center
            lat_off = random.gauss(0, scatter_radius / 2.0)
            lng_off = random.gauss(0, scatter_radius / 2.0)

            lat = round(center_lat + lat_off, 6)
            lng = round(center_lng + lng_off, 6)

            # Pick a timestamp
            dt = random.choice(base_timestamps)
            hr = dt.hour
            is_weekend = dt.weekday() in (5, 6)

            # Apply temporal decibel modifier curve
            db_mod = 0.0
            if tag == "nightlife":
                if is_weekend and (hr >= 20 or hr <= 2):
                    db_mod += random.uniform(15.0, 24.0)
                elif hr >= 18:
                    db_mod += random.uniform(8.0, 14.0)
                else:
                    db_mod -= random.uniform(10.0, 18.0)
            elif tag in ("traffic", "trains"):
                if (7 <= hr <= 10) or (17 <= hr <= 20):
                    db_mod += random.uniform(12.0, 20.0)  # Rush hour
                elif 22 <= hr or hr <= 5:
                    db_mod -= random.uniform(12.0, 20.0)  # Night quiet
                else:
                    db_mod += random.uniform(2.0, 8.0)
            elif tag == "construction":
                if not is_weekend and (8 <= hr <= 17):
                    db_mod += random.uniform(16.0, 26.0)
                else:
                    db_mod -= random.uniform(15.0, 25.0)
            else:
                if 22 <= hr or hr <= 6:
                    db_mod -= random.uniform(8.0, 14.0)
                else:
                    db_mod += random.uniform(-4.0, 6.0)

            decibel = round(max(31.0, min(108.0, base_db + db_mod + random.gauss(0, 3.0))), 1)

            source = "seed" if random.random() > 0.15 else "crowdsourced"

            report = models.NoiseReport(
                lat=lat,
                lng=lng,
                decibel_estimate=decibel,
                timestamp=dt,
                tag=tag,
                source=source,
            )
            reports_buffer.append(report)

    # Bulk insert into database
    db.bulk_save_objects(reports_buffer)
    db.commit()
    count = db.query(models.NoiseReport).count()
    db.close()
    print(f"[SEED TN] Successfully populated Tamil Nadu dataset! Total DB reports: {count}")

if __name__ == "__main__":
    generate_tn_seed_data()
