import datetime
import random
from database import SessionLocal, engine, Base
import models

def seed_demo_pitch_clusters():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    demo_scenes = [
        {
            "name": "Nightlife Strip (East Village Bar Block)",
            "center_lat": 40.728,
            "center_lng": -73.985,
            "profiles": [
                (datetime.datetime(2026, 7, 22, 8, 0), 42.0, "nightlife", "crowdsourced"),  # Morning
                (datetime.datetime(2026, 7, 22, 14, 0), 46.5, "nightlife", "crowdsourced"), # Afternoon
                (datetime.datetime(2026, 7, 22, 20, 0), 74.0, "nightlife", "crowdsourced"), # Evening
                (datetime.datetime(2026, 7, 22, 23, 30), 86.5, "nightlife", "crowdsourced"),# Night
                (datetime.datetime(2026, 7, 25, 23, 45), 89.0, "nightlife", "crowdsourced"),# Weekend Night
            ]
        },
        {
            "name": "Transit Station (Grand Central Subway Hub)",
            "center_lat": 40.750,
            "center_lng": -73.977,
            "profiles": [
                (datetime.datetime(2026, 7, 22, 8, 15), 79.5, "trains", "crowdsourced"),  # Morning Rush
                (datetime.datetime(2026, 7, 22, 13, 30), 61.0, "trains", "crowdsourced"), # Afternoon
                (datetime.datetime(2026, 7, 22, 18, 0), 77.0, "trains", "crowdsourced"),  # Evening Rush
                (datetime.datetime(2026, 7, 22, 23, 0), 49.0, "trains", "crowdsourced"),  # Night
            ]
        },
        {
            "name": "Quiet Residential Block (Greenwich Parkside)",
            "center_lat": 40.710,
            "center_lng": -73.960,
            "profiles": [
                (datetime.datetime(2026, 7, 22, 9, 0), 41.5, "other", "crowdsourced"),   # Morning
                (datetime.datetime(2026, 7, 22, 15, 0), 43.0, "other", "crowdsourced"),  # Afternoon
                (datetime.datetime(2026, 7, 22, 19, 0), 42.0, "other", "crowdsourced"),  # Evening
                (datetime.datetime(2026, 7, 22, 23, 0), 37.5, "other", "crowdsourced"),  # Night
            ]
        }
    ]

    total_added = 0
    for scene in demo_scenes:
        lat = scene["center_lat"]
        lng = scene["center_lng"]

        for dt, base_db, tag, source in scene["profiles"]:
            # Generate 3-4 cluster points per timestamp with slight variation
            for _ in range(3):
                offset_lat = random.uniform(-0.0006, 0.0006)
                offset_lng = random.uniform(-0.0006, 0.0006)
                db_val = round(base_db + random.uniform(-2.5, 2.5), 1)

                report = models.NoiseReport(
                    lat=round(lat + offset_lat, 6),
                    lng=round(lng + offset_lng, 6),
                    decibel_estimate=db_val,
                    timestamp=dt,
                    tag=tag,
                    source=source
                )
                db.add(report)
                total_added += 1

    db.commit()
    db.close()
    print(f"[DEMO SEED] Successfully inserted {total_added} pitch-perfect crowdsourced reports into database!")

if __name__ == "__main__":
    seed_demo_pitch_clusters()
